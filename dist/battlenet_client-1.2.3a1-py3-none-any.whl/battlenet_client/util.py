"""This module defines utility functions for use in the battle.net rest API

.. moduleauthor: David Couples <gahdania@gahd.io>
"""


