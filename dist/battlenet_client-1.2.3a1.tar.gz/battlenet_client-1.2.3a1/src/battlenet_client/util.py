"""Defines utility functions for use in the battle.net rest API

.. moduleauthor: David "Gahd" Couples <gahdania@gahd.io>
"""


