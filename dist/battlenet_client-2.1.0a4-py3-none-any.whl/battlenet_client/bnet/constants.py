"""Defines package wide constants

Disclaimer:
    All rights reserved, Blizzard is the intellectual property owner of Battle.net and any data
    retrieved from this API.
"""

NORTH_AMERICA = "us"
EUROPE = "eu"
TAIWAN = "tw"
KOREA = "kr"
CHINA = "cn"
