from battlenet_client import BattleNetCredentialClient
from requests.exceptions import HTTPError

try:
    import unittest2 as unittest
except ImportError:
    import unittest as unittest


class CredentialClientTests(unittest.TestCase):

    def setUp(self):
        _client_id = '59bdfd31c9fd40689e3d0b0a8652692c'
        _client_secret = '0I7k2wrtLr1zusFnombFLOI9ZcKx8evK'
        self.connection = BattleNetCredentialClient('us', locale='en_US', client_id=_client_id,
                                                    client_secret=_client_secret)

    def test_not_found(self):
        self.assertRaises(HTTPError,
                          lambda: self.connection.get('data/wow/playable-class/-1', locale='en_US',
                                                      namespace='static-us'))

    def test_found(self):
        self.assertIsInstance(self.connection.get('data/wow/playable-class/1', locale='en_US',
                                                  namespace='static-us'), dict)

    def tearDown(self):
        del self.connection
