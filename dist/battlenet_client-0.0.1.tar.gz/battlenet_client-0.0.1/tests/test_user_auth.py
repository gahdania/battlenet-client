from battlenet_client import BattleNetUserAuthClient
import flask_testing
from flask import Flask, render_template, session, redirect, request, make_response, url_for

user_auth = Flask(__name__)
user_auth.secret_key = b'73874837483723487384'


class UserAuthClientTest(flask_testing.TestCase):

    @staticmethod
    @user_auth.route('/')
    def index():
        return render_template('index.jinja', user_info=session.get('user_info'))

    @user_auth.route('/login')
    def login(self):
        return redirect(self.client.authorization_url())

    @user_auth.route('/callback')
    def authorize(self):
        uri = ''
        self.client.fetch_access_token(request.uri)
        response = make_response(self.client.get(uri, locale='enus', namespace=self.client.profile_namespace))
        return response

    @staticmethod
    @user_auth.route('/logout')
    def logout():
        if 'user_info' in session:
            del session['user_info']
        return redirect(url_for('index'))

    def create_app(self):
        return user_auth

    def setUp(self):
        self.client = BattleNetUserAuthClient('us', ['wow.profile'], 'https://localhost:5000/callback',
                                              client_id='59bdfd31c9fd40689e3d0b0a8652692c',
                                              client_secret='0I7k2wrtLr1zusFnombFLOI9ZcKx8evK')

    def test_authorization_url(self):
        url = self.client.authorization_url()
        self.assertTrue(url.find('us.battle.net'))
        self.assertTrue(url.find('state'))
        self.assertTrue(url.find('code'))
        self.assertTrue(url.find('redirect_uri'))


# @user_auth.route('/callback')
# def oic_login():
#     auth_response = user_auth.get_authorization_response(request, session)
#     print(auth_response)
#     user_auth.get_access_token(auth_response)
#
#     response = make_response(f"{user_auth.get_user_info('enus')}")
#     return response


if __name__ == "__main__":
    user_auth.run(ssl_context='adhoc', debug=True)
