# BattleNet Clients
BattleNet Clients provide a uniform interface for Blizzard's Battle.net Developer Rest Application Programming
Interface (BNET Rest API) 

## Installation

Windows, OS X & Linux:

    pip install battlenet_client

## Clone
    Clone the latest version: https://gitlab.gahd.io/battlenet/battlenet-clients


## Usage Example
    from battlenet_client import BattlenetClient
    client = BattleNetClient('us', 'enus', client_id='<client id>', client_secret='<client secret>')
    client.get('data/wow/playable-class/1', locale='en_US', namespace='static-us')

_For more examples and usage, please refer to the [Wiki][wiki]._


## Release History
* 0.0.1a1
    * Current Release (Development)

## Meta

David "Gahd" Couples – [@gahdania][twitter] – gahdania@gahd.io

Distributed under the GPL v3+ license. See ``LICENSE`` for more information.

[Battlenet-clients @ gahd.io][gitlab]

## Contributing

1. [Fork it][fork]
2. Create your feature branch (`git checkout -b feature/fooBar`)
3. Commit your changes (`git commit -am 'Add some fooBar'`)
4. Push to the branch (`git push origin feature/fooBar`)
5. Create a new Pull Request

<!-- Markdown link & img dfn's -->
[wiki]: https://battlenet.pages.gahd.io/battlenet-clients
[twitter]: https://twitter.com/gahdania
[gitlab]: https://gitlab.gahd.io/battlenet1/battlenet-clients
[fork]: https://gitlab.gahd.io/battlenet1/battlenet-clients/-/forks/
[header]: https://gilab.gahd.io/